var coveUrl = "https://app.cove.chat/",
    css = "\n.cove-input,.cove-button{font-size:inherit;font-family:inherit;appearance:none;-moz-appearance:none;-webkit-appearance:none;}\n.cove-input{border:1px solid #aaa;outline:none;border-radius:2px;padding:4px 10px;line-height:2;vertical-align:middle}\n.cove-input:focus{border-color:#777;outline:none;box-shadow:0px 0px 4px rgba(0,0,0,0.16)}\n.cove-button{cursor:pointer;white-space:nowrap;text-align:center;outline:none;background-color:#111;border: 1px solid #111;color:#fff;border-radius:2px;padding:4px 10px;line-height:2;vertical-align:middle}\n#cove-login .signin-success,#cove-login .signin-error{display:none}\n#cove-login.success .signin-success{display:block !important;color:green}\n#cove-login.error .signin-error{display:block !important;color:red}\n#cove-login.loading .button-spinner{display:block !important;}\n#cove-login .button-spinner svg {margin:auto}\n#cove-login.loading .button-text{display:none}\n",
    customCss = document.createElement("style");
customCss.id = "cove-style", customCss.appendChild(document.createTextNode(css)), document.getElementsByTagName("head")[0].appendChild(customCss);
var spinnerSvg = '<svg style="vertical-align:middle" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid"><circle cx="50" cy="50" fill="none" stroke="#ccc" stroke-width="12" r="39" stroke-dasharray="183.7831702350029 63.261056745000964" transform="rotate(197.992 50 50)"><animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" values="0 50 50;360 50 50" keyTimes="0;1"/></circle></svg>',
    reactionIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g fill="none" stroke="#aaa" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"><path d="M15.22 6c.179-.53.28-1.035.28-1.5a4 4 0 00-4-4C9.982.5 8.678 1.355 8 2.601 7.322 1.355 6.018.5 4.5.5a4 4 0 00-4 4c0 2.453 2.821 6.035 5.003 8.438"/><circle cx="11.5" cy="11.5" r="4"/><path d="M11.5 9.5v4M9.5 11.5h4"/></g></svg>';

function getParameterByName(e, t) {
    t || (t = window.location.href), e = e.replace(/[\[\]]/g, "\\$&");
    var n = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(t);
    return n ? n[2] ? decodeURIComponent(n[2].replace(/\+/g, " ")) : "" : null
}
var coveAction = getParameterByName("action");
if ("signin" == coveAction && localStorage.coveLoginRedirect) {
    let e = localStorage.coveLoginRedirect;
    localStorage.removeItem("coveLoginRedirect"), window.location.href = e.replace("#cove-comments", "") + "#cove-comments"
}
var coveExists = "undefined" != typeof Cove,
    commentForm, nameInput, commentInput, commentBlock, commentsCount, replyInput, cancelLink, commentTemplate, hasReactions, reactionTypes, newMessageAlert, showBranding, strings, container = document.getElementById("cove"),
    coveCommentCount = document.getElementById("cove-count"),
    loadingMessage = document.createElement("div"),
    cannotComment = !!coveExists && (Cove.requirePaid && !Cove.isPaid);
if (void 0 === scriptWithPub) var scriptWithPub = document.querySelector("script[data-cove-id]");
if (null !== scriptWithPub) var publicationId = scriptWithPub.dataset.coveId;
else var publicationId = Cove.publication;
async function getComments() {
    let e = coveUrl + publicationId + "/api/comments/?contentId=" + Cove.contentId + ("" !== Cove.memberId ? "&member=" + Cove.memberId + "|" + encodeURIComponent(Cove.memberEmail) : ""),
        t = await fetch(e),
        n = await t.json();
    if ("" === n.error) {
        reactionTypes = n.reaction_types, showBranding = n.show_branding, hasReactions = n.has_reactions, loadingMessage.setAttribute("style", "display:none"), commentBlock.innerHTML = "";
        var o = customCss.innerHTML + n.css;
        if (customCss.innerHTML = o, commentTemplate = n.template_html, newMessageAlert.innerHTML = spinnerSvg, comments = n.comments, commentsCount = comments.length, null !== coveCommentCount && (coveCommentCount.innerHTML = commentsCount), comments.forEach((e, t) => {
                addComment(e)
            }), (cannotComment || "" == Cove.memberId) && (Array.from(document.getElementsByClassName("cove-reply")).forEach(function(e) {
                e.style.display = "none"
            }), Array.from(document.getElementsByClassName("cove-reaction-box")).forEach(function(e) {
                e.style.display = "none"
            })), void 0 === commentForm && addForm(n.member), showBranding) {
            var i = document.createElement("div");
            i.setAttribute("style", "text-align:right;font-size:12px"), i.innerHTML = 'Powered by <a href="https://cove.chat" target="_blank" rel="nofollow">Cove</a>', container.parentNode.insertBefore(i, container.nextSibling)
        }
        "" != Cove.memberId && (listenForReplies(), listenForLikes(), listenForReactions()), newMessageAlert.setAttribute("style", "display:none"), newMessageAlert.innerHTML = ""
    } else container.innerHTML = n.error
}

function getStrings() {
    fetch(coveUrl + publicationId + "/api/strings/").then(e => e.json()).then(e => e.strings)
}

function listenForReplies() {
    let e = document.getElementsByClassName("cove-reply");
    Array.from(e).forEach(function(e) {
        e.addEventListener("click", activateReply)
    })
}

function listenForLikes() {
    let e = document.getElementsByClassName("cove-like");
    Array.from(e).forEach(function(e) {
        e.addEventListener("click", toggleLike)
    })
}

function listenForReactions() {
    let e = document.querySelectorAll("[data-cove-emoji]");
    Array.from(e).forEach(function(e) {
        e.addEventListener("click", submitReaction)
    })
}

function coveInit() {
    (commentBlock = document.createElement("div")).setAttribute("id", "cove-comments"), container.appendChild(commentBlock), fetch(coveUrl + publicationId + "/api/strings/").then(e => e.json()).then(e => {
        "" === e.error ? strings = e.strings : container.innerHTML = e.error
    }).then(() => {
        if (loadingMessage.innerHTML = spinnerSvg + "&nbsp; " + strings.loading, null !== container && (container.appendChild(loadingMessage), (newMessageAlert = document.createElement("div")).innerHTML = "", newMessageAlert.setAttribute("style", "display:none"), newMessageAlert.setAttribute("id", "cove-new-alert"), container.appendChild(newMessageAlert), newMessageAlert.addEventListener("click", function(e) {
                getComments()
            })), getComments(), void 0 !== window.event) {
            let e = window.event.target;
            e.parentElement.removeChild(e)
        }
    })
}

function addForm(e) {
    if ("" !== Cove.memberId)
        if (cannotComment)(commentForm = document.createElement("div")).innerHTML = strings.paying_only, container.appendChild(commentForm), Array.from(document.getElementsByClassName("cove-reply")).forEach(function(e) {
            e.parentElement.removeChild(e)
        });
        else {
            (commentForm = document.createElement("form")).id = "cove-form", (commentInput = document.createElement("textarea")).className = "cove-input", commentInput.setAttribute("name", "body"), commentInput.setAttribute("placeholder", 0 == commentsCount ? strings.leave_first_comment : strings.leave_comment), commentInput.setAttribute("required", !0), commentInput.setAttribute("rows", 1), commentInput.id = "cove-input-body", commentInput.setAttribute("onkeyup", "adjustTextarea(this)"), commentForm.appendChild(commentInput), null == e.name ? ((nameInput = document.createElement("input")).className = "cove-input", nameInput.setAttribute("name", "member_name"), nameInput.setAttribute("placeholder", strings.your_name), nameInput.setAttribute("required", !0), nameInput.id = "cove-input-name", commentForm.appendChild(nameInput)) : void 0 !== Cove.memberName && "" != Cove.memberName && ((nameInput = document.createElement("input")).className = "cove-input", nameInput.setAttribute("name", "member_name"), nameInput.value = Cove.memberName, nameInput.setAttribute("type", "hidden"), commentForm.appendChild(nameInput));
            var t = document.createElement("button");
            t.className = "cove-button", t.id = "cove-submit";
            var n = document.createElement("span");
            n.innerHTML = strings.post;
            var o = document.createElement("span");
            o.style = "display:none", o.innerHTML = spinnerSvg, t.appendChild(n), t.appendChild(o), memberIdInput = document.createElement("input"), memberIdInput.setAttribute("name", "member_id"), memberIdInput.setAttribute("type", "hidden"), memberIdInput.value = Cove.memberId, (replyInput = document.createElement("input")).setAttribute("name", "reply_id"), replyInput.setAttribute("type", "hidden"), commentForm.appendChild(t), commentForm.appendChild(memberIdInput), commentForm.appendChild(replyInput), container.appendChild(commentForm), commentForm.addEventListener("submit", function(e) {
                e.preventDefault(), submitComment()
            })
        }
}

function addComment(e) {
    let t = document.createElement("div");
    if (t.setAttribute("class", "cove-comment"), t.setAttribute("data-cove-id", e.uuid), t.id = "cove-" + e.uuid, t.innerHTML = getCommentHTML(e), showReactions(t, e.reactions, e.member_reaction), "" !== Cove.memberId && !cannotComment) {
        let e = t.getElementsByClassName("cove-reply")[0];
        e.parentNode.insertBefore(document.createTextNode(" •"), e.nextSibling)
    }
    if ("" !== Cove.memberId || Object.keys(e.reactions).length > 0) {
        let e = t.querySelectorAll(".cove-footer .cove-date")[0];
        void 0 !== e && e.parentNode.insertBefore(document.createTextNode(" •"), e.nextSibling)
    }
    e.parent ? (parentList = document.querySelectorAll(`[data-cove-id='${e.parent}']`), parentList[0].appendChild(t)) : commentBlock.appendChild(t)
}

function showReactions(e, t, n) {
    let o = e.getElementsByClassName("cove-reactor")[0];
    if (o.innerHTML = "", "off" != hasReactions)
        if ("likes" == hasReactions) {
            for (var i in t)
                if (t.hasOwnProperty(i)) {
                    let e = document.createElement("span");
                    e.className = "cove-like" + ("heart" == n ? " active" : ""), e.innerHTML = i + " " + t[i], o.appendChild(e)
                }
        } else if ("emoji" == hasReactions) {
        for (var i in o.appendChild(document.createTextNode(" ")), t)
            if (t.hasOwnProperty(i)) {
                let e = document.createElement("span");
                e.className = "cove-reaction" + (n == i ? " active" : ""), e.innerHTML = i + " " + t[i], o.appendChild(e)
            }
        let e = document.createElement("span");
        e.className = "cove-reaction-box";
        let c = document.createElement("span");
        if (c.className = "cove-reaction-button", c.innerHTML = reactionIcon, e.appendChild(c), "" != Cove.memberId) {
            var r = "";
            for (var a in reactionTypes) reactionTypes.hasOwnProperty(a) && (r += `<span data-cove-emoji="${a}">${reactionTypes[a]}</span>`);
            let t = document.createElement("div");
            t.className = "cove-reaction-menu", t.innerHTML = r, e.appendChild(t)
        }
        o.appendChild(e)
    }
}
async function submitComment() {
    nameMessage = document.getElementById("cove-name-message"), nameMessage && nameMessage.parentElement.removeChild(nameMessage);
    let e = coveUrl + publicationId + "/api/comments/" + Cove.contentId + "/";
    const t = new FormData(commentForm);
    let n = await fetch(e, {
            method: "POST",
            body: t
        }),
        o = await n.json();
    if ("" != o.error) {
        let e = document.createElement("div");
        e.id = "cove-name-message", e.innerHTML = o.error, commentForm.parentNode.insertBefore(e, commentForm.nextSibling)
    } else addComment(o.comment), commentInput.setAttribute("placeholder", strings.leave_comment), commentsCount = o.total_count, null !== coveCommentCount && (coveCommentCount.innerHTML = commentsCount), commentInput.setAttribute("rows", 1), removeCancelLink(), listenForReplies(), listenForLikes(), listenForReactions(), container.appendChild(commentForm), commentInput.value = "", void 0 !== nameInput && nameInput.parentElement.removeChild(nameInput), replyInput.value = ""
}

function getCommentHTML(comment) {
    var replyString = strings.reply,
        pinnedHTML = comment.pinned_html.replace("[COPY]", strings.pinned || "Pinned");
    return eval("`" + commentTemplate + "`")
}

function activateReply(e) {
    if (e.preventDefault(), "" == Cove.memberId) return;
    Array.from(document.getElementsByClassName("cove-cancel")).forEach(function(e) {
        e.parentElement.removeChild(e)
    });
    let t = e.target.closest(".cove-comment");
    t.parentElement.className.indexOf("cove-comment") > -1 ? parentComment = t.parentElement : parentComment = t, parentComment.appendChild(commentForm), checkVisible(commentForm) || commentForm.scrollIntoView(!1), commentInput.focus(), (cancelLink = document.createElement("a")).href = "#", cancelLink.className = "cove-cancel", cancelLink.innerHTML = strings.cancel_reply, parentComment.appendChild(cancelLink), replyInput.setAttribute("value", t.getAttribute("data-cove-id")), cancelLink.addEventListener("click", cancelReply)
}

function checkVisible(e) {
    var t = e.getBoundingClientRect(),
        n = Math.max(document.documentElement.clientHeight, window.innerHeight);
    return !(t.bottom < 0 || t.top - n >= 0)
}

function cancelReply(e) {
    e.preventDefault(), removeCancelLink(), container.appendChild(commentForm), commentInput.value = "", replyInput.value = "", listenForReplies()
}

function removeCancelLink() {
    void 0 !== cancelLink && (cancelLink.removeEventListener("click", cancelReply), cancelLink.parentElement.removeChild(cancelLink))
}
async function toggleLike(e) {
    e.preventDefault();
    let t = e.target.closest(".cove-like"),
        n = t.closest(".cove-comment"),
        o = n.getAttribute("data-cove-id"),
        i = (t.className.indexOf("active"), coveUrl + publicationId + "/api/comment-reactions/" + o + "/"),
        r = await fetch(i, {
            method: "POST",
            body: JSON.stringify({
                member_id: Cove.memberId,
                reaction: "heart"
            })
        }),
        a = await r.json();
    "" != a.error || (showReactions(n, a.reactions, a.member_reaction), listenForLikes())
}
async function submitReaction(e) {
    e.preventDefault();
    let t = e.target.closest("[data-cove-emoji]"),
        n = t.closest(".cove-comment"),
        o = n.getAttribute("data-cove-id"),
        i = t.getAttribute("data-cove-emoji"),
        r = coveUrl + publicationId + "/api/comment-reactions/" + o + "/",
        a = await fetch(r, {
            method: "POST",
            body: JSON.stringify({
                member_id: Cove.memberId,
                reaction: i
            })
        }),
        c = await a.json();
    "" != c.error || (showReactions(n, c.reactions, c.member_reaction), listenForReactions())
}
coveExists && !1 !== Cove.autoLoad && coveInit();
var loginForm = document.getElementById("cove-login");

function adjustTextarea(e) {
    var t = e.value,
        n = (t = (t = t.replace(new RegExp("\n\r", "gi"), "\n")).replace(new RegExp("\r", "gi"), "\n")).split("\n");
    e.rows = n.length
}
if (null !== loginForm && loginForm.addEventListener("submit", function(e) {
        localStorage.coveLoginRedirect = window.location.href.replace(window.location.search, "")
    }), null === scriptWithPub) console.error("Cove error: To display post counts, you need to add your publication ID to your Cove script tag.");
else {
    let e = document.querySelectorAll("[data-cove-count-comments]"),
        t = document.querySelectorAll("[data-cove-count-likes]"),
        n = document.querySelectorAll("[data-cove-count-views]"),
        o = document.querySelectorAll("[data-cove-count-reactions]"),
        r = [];
    for (var i = 0; i < e.length; i++) r.push(e[i].dataset.coveCountComments);
    for (var i = 0; i < t.length; i++) r.push(t[i].dataset.coveCountLikes);
    for (var i = 0; i < n.length; i++) r.push(n[i].dataset.coveCountViews);
    for (var i = 0; i < o.length; i++) r.push(o[i].dataset.coveCountReactions);
    r = [...new Set(r)], r.length > 0 && fetch(coveUrl + scriptWithPub.dataset.coveId + "/api/counts/?ids=" + r.join(",")).then(e => e.json()).then(e => {
        if ("" === e.error)
            for (var t = 0; t < e.counts.length; t++) {
                let m = e.counts[t],
                    s = m.id,
                    l = document.querySelectorAll('[data-cove-count-comments="' + s + '"]');
                for (var n = 0; n < l.length; n++) {
                    var o = l[n].dataset;
                    if (1 == parseInt(m.comments)) var i = void 0 !== o.translateComment ? o.translateComment : "comment";
                    else i = void 0 !== o.translateComments ? o.translateComments : "comments";
                    l[n].innerHTML = m.comments.toLocaleString() + " " + i
                }
                let d = document.querySelectorAll('[data-cove-count-likes="' + s + '"]');
                for (var r = 0; r < d.length; r++) {
                    o = d[r].dataset;
                    if (1 == parseInt(m.likes)) i = void 0 !== o.translateLike ? o.translateLike : "like";
                    else i = void 0 !== o.translateLikes ? o.translateLikes : "likes";
                    d[r].innerHTML = m.likes.toLocaleString() + " " + i
                }
                let u = document.querySelectorAll('[data-cove-count-views="' + s + '"]');
                for (var a = 0; a < u.length; a++) {
                    o = u[a].dataset;
                    if (1 == parseInt(m.views)) i = void 0 !== o.translateView ? o.translateView : "view";
                    else i = void 0 !== o.translateViews ? o.translateViews : "views";
                    u[a].innerHTML = m.views.toLocaleString() + " " + i
                }
                let p = document.querySelectorAll('[data-cove-count-reactions="' + s + '"]');
                for (var c = 0; c < p.length; c++) {
                    o = p[c].dataset;
                    if (0 == parseInt(m.reactions)) i = "No reactions";
                    else i = m.top_reaction + " " + m.reactions.toLocaleString();
                    p[c].innerHTML = i
                }
            } else console.error("Cove error: " + e.error)
    })
}